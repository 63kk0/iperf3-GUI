Comparison With Speedtest.net
=============================

Here is a quick comparison between iperf3 and speedtest.net. This is on my wired internet connection (1Gbit/s down 30 Mbit/s up)

Of course there are a much more limited number of iperf3 public servers...

![iperf3](https://github.com/NickWaterton/iperf3-GUI/blob/master/Comparison%20With%20Speedtest.net/Screenshot%202018-05-01%2008.54.35.png "iperf3")
![speedtest](https://github.com/NickWaterton/iperf3-GUI/blob/master/Comparison%20With%20Speedtest.net/7273267406.png "speedtest")